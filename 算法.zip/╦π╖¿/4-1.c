//�᳡��������
#include<stdio.h>    
#include<stdlib.h>       
struct node    
{    
    int begin,end;    
}a[10001],b[10001];    
int cmp(const void *a,const void *b)    
{    
    return (*(struct node *)a).begin>(*(struct node *)b).begin?1:-1;    
}    
int main()        
{        
    int i,j,n,k,t;        
    scanf("%d",&n);     
    for(i=0;i<n;i++)    
scanf("%d %d",&a[i].begin,&a[i].end);    
    qsort(a,n,sizeof(a[0]),cmp);    
        k=1;        
        b[0]=a[0];    
        for(i=1;i<n;i++)        
        {        
            t=0;            
            for(j=0;j<k;j++)        
            {        
                if(a[i].begin>=b[j].end)        
                {        
                    t=1;        
                    b[j]=a[i];        
                    break;        
                }        
            }        
            if(t==0)        
                b[k++]=a[i];        
        }        
        printf("%d\n",k);        
    } 